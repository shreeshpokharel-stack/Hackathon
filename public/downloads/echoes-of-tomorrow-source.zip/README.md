# Echoes of Tomorrow — Temporal Puzzle Adventure

Simultaneous split-screen **Past (2089)** & **Future (2189)** puzzle-platformer featuring a Princess of Persia–inspired temporal acrobat, Chrono Shift (`Q`), Temporal Freeze (`F`), Butterfly Effects, and 3 interconnected levels.

## Quick Run (Source)
```bash
npm install
npm run dev
```

## Build for Static Hosting
```bash
npm run build
```

## Controls
- `A` / `D` or `←` / `→`: Move (synced across Past & Future)
- `Space` / `W` / `↑`: Jump
- `E`: Interact (free wildlife, plant seeds, collapse supports, activate conduits)
- `Q`: Chrono Shift between 2089 and 2189
- `F`: Temporal Freeze (5s, freezes Future drones)
- `R`: Reset current level
- `Esc` / `P`: Pause menu
